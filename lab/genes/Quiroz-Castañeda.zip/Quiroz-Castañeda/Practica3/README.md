# Práctica 3: Algoritmos evolutivos

Tanto el código como las respuestas están hechas en formato de cuarderno de
[Jupyter](https://jupyter.org/).

Se realizaron en el lenguaje [Julia](https://julialang.org/). Para correrlas, se
necesita tener instalado algún programa que pueda leer cuadernos de Jupyter,
como [Jupyter Lab](https://jupyterlab.readthedocs.io/en/stable/) o
[Nteract](https://github.com/nteract/nteract), además de tener instalado el
[kernel de Julia](https://github.com/JuliaLang/IJulia.jl) para Jupyter.

Con estos, basta con abrir los archivos con dicho programa.
