Hay tres programas fuentes. Todos fueron hechos en Netlogo. Basta con
importarlos al editor.

ECA implementa los autómatas celulares elementales. En la vista se puede elegir
la regla, el tamaño, además de tres tipos de condiciones iniciales. Una
aleatoria, uno donde todos están vivos y otra donde solo uno está vivo.

En el código también están los métodos para realizar las perturbaciones, pero
estos requieren de una pantalla tres veces más larga que ancha. Estos solo se
usaron para realizar las imágenes.

LIFE implementa el juego de la vida. Permite definir la densidad y genera una
configuración inicial. Además grafica la cantidad de células vivas.

LOGIC implementa las compuertas lógicas en el juego de la vida. permite
seleccionar el circuito a simular y las entradas que se alimantarán al
circuito.